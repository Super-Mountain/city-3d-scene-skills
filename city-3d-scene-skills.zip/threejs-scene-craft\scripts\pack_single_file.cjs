// 单文件离线打包：把 index.html 引用的本地 JS 内联成一个 HTML
// 用法：修改 ROOT / ENTRY / OUTPUT / SCRIPTS 后运行
//   "C:/Users/Administrator/.workbuddy/binaries/node/versions/22.22.2-6/node.exe" pack_single_file.cjs
//
// ⚠️ 关键坑（已踩过）：html.replace(marker, 大段JS字符串) 会把压缩库里的
//    $& / $' 等序列当特殊替换符，复制出多余 script 标签，DOM 畸形。
//    必须使用函数替换：replace(marker, () => inline)。本脚本已内置。

const fs=require('fs');
const ROOT='C:/path/to/project/';
const ENTRY='index.html';
const OUTPUT='dist-offline.html';
const SCRIPTS=['three.min.js','scene.js']; // 按 ENTRY 中引用顺序

const html=fs.readFileSync(ROOT+ENTRY,'utf8');
const esc=s=>s.replace(/<\/script/g,'<\\/script');
const inline=SCRIPTS.map(f=>'<script>\n'+esc(fs.readFileSync(ROOT+f,'utf8'))+'\n</script>').join('\n');
const marker=SCRIPTS.map(f=>`<script src="./${f}"></script>`).join('');
if(!html.includes(marker))throw new Error('script marker not found: '+marker);
const out=html.replace(marker,()=>inline); // 函数替换，避免 $ 特殊符陷阱
fs.writeFileSync(ROOT+OUTPUT,out);
console.log(JSON.stringify({file:ROOT+OUTPUT,bytes:Buffer.byteLength(out)}));

// 打包后自检：script 标签数应该恰好等于 SCRIPTS.length
const openCount=(out.match(/<script/g)||[]).length;
if(openCount!==SCRIPTS.length)throw new Error('script tag count mismatch: '+openCount+' (可能发生 $ 替换污染)');
console.log('script tags:',openCount,'OK');
