# City 3D Scene Skills

用 AI（ZCode / Claude 等编码智能体）从零构建**真实城市 3D 场景**的两个技能包。源自"武汉两江三镇"项目实战：Three.js + OpenStreetMap 真实数据，15000+ 栋建筑、49 个手工地标、19 艘按真实航运规则双向分道的船，浏览器实时渲染。

**在线成品**：https://wuhan-3d-scene.app.workbuddy.host

## 两个技能

### 🏙️ city-3d-scene —— 城市级构建方法论（宏观）

把"做一个城市的 3D 场景"变成一条有纪律的流水线。核心是**骨肉皮分层**：

```
髓  数据管线（OSM抓取/投影/水陆判定）  → 三方判定一致，固化唯一快照
骨  江湖山+主干道+航道                → 坐标要准，一次定型后冻结
关节 地标（黄鹤楼/桥/站/大学/医院）    → 手雕，逐个过近景验收
肉  填充建筑/支路/店招                → 模板×摆放规则×占位网格
皮  船/车/人/鸟/烟花                  → 生动，可无限追加
```

内含六份操作手册：Overpass 分瓦片抓取、投影公式、chainRings 水环拼合、山体脊线、航道锚点+螺旋吸附、地标摆放三保险、占位网格、InstancedMesh 性能、双向分道、**45+ 条真实踩坑教训**。

### 🎨 threejs-scene-craft —— 单场景画质工艺（微观）

把"能跑的 demo"做到"画质像成品"。差距不在模型数量，在光影、材质、性能预算和**实测闭环**：

- 视觉质量手册：低饱和暖调配色调色板、灯光三层结构、五类程序化 Canvas 纹理配方（木纹/灰泥/石材/布料/草地）
- `verify_scene.cjs`：Playwright **真实按键**自动验收模板（禁 teleport），断言碰撞数值、drawCalls<150、窄屏溢出、控制台零错误
- `pack_single_file.cjs`：单文件离线打包（已修 `$&` 替换陷阱）

## 安装

**方式 A：git clone（推荐，更新方便）**

```bash
cd ~/.agents/skills        # ZCode / Claude Code 的技能目录
git clone https://github.com/<你的用户名>/city-3d-scene-skills.git
```

**方式 B：下载 zip 手动放置**

把 `city-3d-scene/` 和 `threejs-scene-craft/` 两个文件夹复制到：
- ZCode / Claude Code：`~/.agents/skills/` 或项目内 `.agents/skills/`
- WorkBuddy：`~/.workbuddy/skills/`

**验证**：新会话里说"做一个长沙的 3D 场景"，技能应自动触发（或 `/city-3d-scene` 显式调用）。

## 使用流程（以长沙为例）

1. 说"做一个长沙湘江两岸的 3D 场景" → 技能触发，AI 给出**层次规划表**归层所有元素
2. 每阶段开工前 AI 会发**方案卡**（目标/清单/素材/验收标准），你确认后动工
3. 数据管线 → 骨架（湘江/岳麓山/主干道，坐标断言验收）→ 地标（橘子洲/岳麓书院）→ 填充建筑 → 船车行人
4. 每阶段完工交**验收报告**，骨层结束有"冻结仪式"

## 依赖

- ZCode / Claude Code 等支持 Agent Skills 的 AI 编程环境
- 自动验收需 Playwright（技能会指引）；发布托管推荐任意静态托管（本项目用 WorkBuddy）
