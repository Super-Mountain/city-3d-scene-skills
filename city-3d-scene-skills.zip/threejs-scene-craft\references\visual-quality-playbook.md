# 视觉质量手册（Visual Quality Playbook）

写场景前通读一遍。所有配方均来自实测通过的成品项目。

## 1. 配色体系

- **低饱和暖调**是"高级感"的捷径。暮色场景基准板：
  - 墙面灰泥 `#e6e0d0`、外墙 `#eee6d4`
  - 木材 `#ad8358` / 深木 `#735038` / 橡木 `#d2ba8b`
  - 草地 `#9baa7c`、树叶三档 `#66835c / #7e9359 / #526d4b`
  - 点缀黄铜 `#b49753`、陶土 `#c59771`
- 全场景材质集中在一个常量对象里定义，**禁止散落的即兴色值**。
- 材质默认 `roughness: 0.8+`；金属才给 `metalness`，且控制在 0.65~0.7。

## 2. 灯光三层结构

1. **半球光**定基调：天光色偏冷、地面反照偏暖，强度 2 左右。
2. **平行光（太阳）**产主阴影：位置低角度（黄昏感），`castShadow`，阴影相机范围紧贴场景边界，`bias: -0.0004`、`normalBias: 0.035` 防条纹。
3. **点光做氛围**：落地灯、吊灯、庭院灯，暖色 `#ffd195`~`#ffc888`，衰减 2。**总数个位数**，每个都要有明确的实体灯具载体。

可交互灯光：灯罩材质用 `emissive`，开关时同步改 `emissiveIntensity` 和点光强度，用户能立刻看到反馈。

## 3. 程序化 Canvas 纹理

每类材质一个 256×256 生成函数，返回 `CanvasTexture`（`colorSpace = SRGBColorSpace`，`RepeatWrapping`）：

- **木纹**：底色 + 200 条贝塞尔曲线半透明描边，抖动 y 坐标。
- **灰泥/墙面**：底色 + 18000 个 1px 噪点（明度随机）。
- **石材**：底色 + 12000 个随机大小斑块。
- **布料**：底色 + 3px 间隔双向网格线。
- **草地**：底色 + 10000 条短笔触，两色交替。

关键参数：`anisotropy` 取 `min(4, 硬件上限)`；大面积地面 `repeat` 铺平。

## 4. 天空与远景

- 渐变天空球：半径 70 球体 + ShaderMaterial（`BackSide`，`depthWrite: false`），片元按 `normalize(v).y` 混合顶/底色。
- 远山：13 个低段数 Cone，深灰绿 `#7d9188`，`castShadow = false`，错落摆放。
- 曝光 1.1 左右的 ACES 会让天空渐变呈现胶片感。

## 5. 阴影性能

```js
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.shadowMap.autoUpdate = false;   // 关键：静态场景不逐帧重算
// 动态事件（门开合角度变化超过阈值）时：
renderer.shadowMap.needsUpdate = true;
```

- 太阳阴影贴图 1024 起步；InstancedMesh 树叶 `castShadow = true` 很出效果但要计入预算。
- 透明玻璃、窗帘 `castShadow = false`。

## 6. 细节层次（"丰富但不乱"的秘诀）

按距离分层添加细节，近处密、远处省：

- 踢脚线、窗框、门把手（黄铜小圆柱）——便宜但极大提升"完成度"。
- 书架放 30+ 本高度颜色随机、轻微倾斜的书，而不是一块纯色板。
- 石板路 12 块逐块轻微旋转；木地板用 InstancedMesh + 每块 `setColorAt` 色差。
- 花坛：茎（细圆柱）+ 5 瓣小花（压扁球体），55 组只需几十 drawCall。

## 7. HUD 与排版（网页质感的一半在 UI）

- 字体栈：`'Segoe UI','Microsoft YaHei'`；标题混排 Georgia 衬线 + 中文，字母间距拉大（`letter-spacing: 5px`）。
- 卡片：`#faf8f0ec` 半透明米色 + 3~5px 圆角 + 左侧 3px 橄榄色强调条。
- 按钮：主按钮深绿 `#354d42` 底 + 米字；次按钮无边框文字款。
- 准星：居中十字，细线低透明。
- 移动端断点 390px：顶栏工具条 `flex-wrap: wrap` + `max-width`，验收断言 `scrollWidth === innerWidth`。

## 8. 构图与镜头

- 概览镜头从高处 45° 俯看全院；漫游视点高 1.64m，坐姿降到 1.1m。
- FOV 62，近裁剪面 0.07（避免贴墙穿模），远裁剪面 130 配合天空球。
- 截图取景至少 4 张：概览、室内近景、特色场景（水庭/廊架）、夜景，外加 390×844 移动端。
