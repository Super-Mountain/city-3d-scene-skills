# 髓 · 数据管线操作手册

## 数据源：Overpass API 抓 OSM

单次大查询对廉价镜像必 504。**必须分瓦片 + 多镜像重试 + 本地合并**：

```
1. 把目标城市 bbox 切成 N×M 瓦片（武汉 14×11km 用了 3×4=12 片）
2. 每片发 Overpass QL：
   [out:json][timeout:90];
   (way["building"]({{bbox}});way["natural"="water"]({{bbox}});...);
   out geom;
3. 镜像轮换重试（maps.mail.ru / overpass-api.de / osm.ch 等各有奇癖）
4. python 合并去重，落盘 data/<city>.json
```

坑：osm.ch 只答瑞士的查询；某些镜像对 `out geom` 支持不全；瓦片边缘的 way 会被切成两半（引出 chainRings）。

## 解析（parseOverpass 模式）

要素分类按 tags：
- `building` → 建筑（闭合 ring + 面积）
- `natural=water` / `waterway=riverbank` → 水（**闭合环与开放段分开收集**）
- `highway=*` → 路（记 kind/bridge/name）
- `railway=rail` → 铁路
- name 命中关注名单 → 单独收进 named 表（地标锚点用）

## chainRings：跨瓦片水环拼合（最大坑）

湖和长江在瓦片边缘被切成开放线段，必须按**端点精确相等（1e-6）**拼接：

```js
// 要点：四向尝试接（尾接头/尾接尾/头接尾/头接头），开链也保留（长江就是开链闭合大环）
// 粗阈值(如2u)拼接会拼出完全错误的环——离线验证必须 1e-6
```

验证：拼合后抽 20 个已知点断言 inRing 正确（江心 W、市中心 L）。

## 投影

```js
const CENTER = { lat: 城市中心纬度, lon: 中心经度 };
const SCALE = 0.25;                       // 1 单位 = 4 米
const U_LAT = 110946 * SCALE;             // 米/度纬度
const U_LON = 111320 * Math.cos(CENTER.lat * Math.PI / 180) * SCALE;
toXZ = (lon, lat) => ({ x: (lon - CENTER.lon) * U_LON, z: (CENTER.lat - lat) * U_LAT });
```

z 取负：Three.js 屏幕里北要"远去"。

## 水陆判定（唯一权威）

- 建 `buildWaterIndex`（bbox 网格空间索引）供运行时 O(1) 查询
- 判定只用快照的拼合环，**禁止各系统自行重算**
- 已知陷阱：
  - 射线探针会被透明物/自身构件挡住误判（烟囱挡住湖水、船体挡住江面）——水陆判定以数据侧为准，射线只做辅助
  - `largestWaterRing` 按 bbox 跨度选环，跨瓦片超级链（含两岸陆地边线）可能选出畸形环——**航道/泊位计算前先肉眼确认选中的是主水环**
  - 页面运行时与离线分析的环拼合结果可能不同（解析顺序影响），必须双闭环验证
