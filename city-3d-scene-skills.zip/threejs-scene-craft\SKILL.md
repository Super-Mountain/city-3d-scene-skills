---
name: threejs-scene-craft
description: 打造高画质、高质感的 Three.js 单文件 3D 交互场景/网页漫游原型。当用户要求做 3D 场景、第一人称漫游、虚拟展厅/庭院/房间、WebGL 可视化、沉浸式网页，或抱怨已有 3D  demo "太简陋、画质差、没质感、不像成品"时使用。涵盖暮色级光影配色、程序化纹理、InstancedMesh 性能优化、碰撞与交互、无头浏览器真实按键验收全流程。Trigger on: Three.js, 3D scene, 3D漫游, 虚拟展厅, WebGL scene, walkthrough, first-person scene, 画质, 质感, 沉浸式网页.
agent_created: true
---

# Three.js Scene Craft

## Overview

把"能跑的 3D demo"做到"画质质感甩开同类几条街的成品"。核心信念：**差距不在模型数量，在光影、材质体系、性能预算和实测闭环**。本技能固化了一套经过真实项目验证的工作流与验收脚本。

## 核心工作流（五步，顺序执行）

### 1. 先定氛围，再写代码

- 用一句话锁定情绪（如"暮色庭院""雨后工作室"），所有配色、灯光、材质围绕它展开。
- 选一个**主色调色板**（3~5 色，低饱和、暖调优先），写进材质常量表，全场景复用，禁止临场随手挑色。
- 参考 `references/visual-quality-playbook.md` 的配色与灯光章节。

### 2. 画质地基（必须全部落实，缺一项就会"露怯"）

- 渲染器：`outputColorSpace = SRGBColorSpace` + `ACESFilmicToneMapping`（曝光 1.0~1.2）+ `PCFSoftShadowMap`。
- 纹理：**程序化 Canvas 纹理**（木纹/灰泥/布料/草地/石材各一个生成函数），256×256 足够，加噪点和笔触；不依赖外部贴图，保证单文件离线可用。
- 天空：自定义 ShaderMaterial 渐变球（`BackSide`），顶部冷色、底部暖色。
- 远景：低多边形剪影（山/树线）+ 大气雾感，制造景深。
- 灯光三层结构：半球环境光定基调 → 平行光（太阳）产主阴影 → 少量暖色点光做氛围。**点光总数控制在个位数**。

### 3. 性能预算（流畅是质感的一部分）

- 重复物体一律 `InstancedMesh`：树叶、草、花瓣、地板条、水滴。
- 静态家具/墙体合并或复用几何体；目标：**漫游视角 drawCalls < 150**。
- 阴影：`shadowMap.autoUpdate = false`，仅在门开合等动态变化时手动 `needsUpdate = true`；阴影贴图 1024 起步，不够再升。
- `setPixelRatio(Math.min(devicePixelRatio, 1.5))`。

### 4. 交互与碰撞（"能玩"和"能看"的分水岭）

- 碰撞用简化 AABB/圆柱列表，**只取膝盖到头顶高度段**参与碰撞，门楣、屋顶不挡人。
- 可开合门：视觉门扇不参与碰撞，门洞始终可通行，接近自动开、离开缓慢合；手动交互设冷却。
- 交互判定：射线 + 距离双重校验，命中后在 HUD 显示提示，按 E 触发；坐下类交互要真实降低视点并可起身。
-  PointerLock 必须带 catch 降级为拖动视角（无头环境/iframe 会拒绝）。
- 提供 `window.__scene` 调试 API（state/position/aim/move/view/setTheme），这是第 5 步自动化验收的前提。

### 5. 实测验收闭环（"甩开别人"的真正来源）

每一版都必须过自动化实测，禁止凭感觉交付：

- 复制 `scripts/verify_scene.cjs` 到项目，按场景改交互点位，用受管 Node 运行。
- 必检项：真实键盘按键穿行（不是 teleport）、双向通行、暂停/恢复、墙体碰撞数值断言、每个交互点实际触发、坐姿视点变化、窄屏无横向溢出、控制台 0 错误。
- 截图直出：概览/室内/特色场景/夜景/移动端各一张，**用 Read 工具亲眼看过截图再交付**。
- 无头浏览器用软件渲染帧率低是正常的，等待超时拉长到 45s，不要把慢误判为卡死。

## 交付打包

- 单文件离线版用 `scripts/pack_single_file.cjs` 内联 JS。
- **关键坑**：`String.replace(marker, 大段JS)` 会把压缩库里的 `$&`/`$'` 当特殊替换符，复制出多余 script 标签、DOM 畸形、窄屏误判超宽。**必须用函数替换** `replace(marker, () => inline)`。脚本里已处理好，直接用。
- 打包后必须重跑一次完整验收（DOM 结构会变）。

## 常见翻车点（已踩过，勿复踩）

| 症状 | 根因 | 解法 |
|---|---|---|
| 门过不去 | 门扇/门框参与了碰撞，或碰撞体覆盖整个门洞 | 碰撞体只取通行高度段，门洞两侧立柱分开建模 |
| 画面灰平 | 没开 ACES / 灯光只有一盏 / 材质全默认 | 落实第 2 步全部地基项 |
| 卡顿 | 每棵树几百个独立 Mesh | InstancedMesh 合并，drawCalls 纳入验收断言 |
| 移动端横向滚动条 | 顶栏/底栏固定宽度溢出 | 390×844 视口断言 `scrollWidth === innerWidth` |
| 交付后才发现交互坏了 | 只 teleport 测试，没按真实按键 | 用 `keyboard.down('KeyW')` 走完全程 |

## Resources

- `references/visual-quality-playbook.md` — 配色、灯光、材质、纹理、构图的详细配方，写场景前必读。
- `scripts/verify_scene.cjs` — Playwright 真实按键验收模板，复制到项目后改交互点位即可用。
- `scripts/pack_single_file.cjs` — 单文件离线打包脚本（已内置 `$` 替换陷阱修复）。
