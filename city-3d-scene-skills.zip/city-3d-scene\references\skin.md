# 皮 · 动态层操作手册

## 统一调度

animate 主循环只做分发，每类动态一个 update 函数：

```js
function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), 0.05);
  time += dt;
  updateDayNight(dt); updateBoats(dt); updateCars(dt);
  updateWalkers(dt); updateBirds(dt); updateFireworks(dt); ...
}
```

兜底：`setInterval(2.5s)` 检查 lastRenderT，超时补渲染帧 + 推进相机 tween（后台标签页 rAF 全停时依然可用）。

## 路径驱动（全部引用骨层数据）

- **船**：沿航道 CatmullRom 曲线，`getPointAt(t)` + `getTangentAt(t)` 定朝向
- **车**：沿路网线段插值 + 路口红灯判定
- **人**：沿岸线/广场环的密集折线走，胶囊 InstancedMesh + instanceColor 调色板
- 相位错开 `t0`、速度分档，防叠队

## 双向分道（航运/车道规则）

```js
const dir = boat.userData.dir;               // ±1
const t = ((time * speed * dir + t0) % 1 + 1) % 1;
const pos = curve.getPointAt(t);
const tan = curve.getTangentAt(t);
const side = (dir === -1) ? 11 : 0;          // 上水沿左法向偏移
boat.position.set(pos.x - tan.z * side, ..., pos.z + tan.x * side);
const ahead = curve.getPointAt((t + 0.004 * dir) % 1);   // 朝向随 dir 翻转
boat.rotation.y = Math.atan2(ahead.x - pos.x, ahead.z - pos.z) - Math.PI / 2;
```

⚠️ 分道偏移必须沿**切线法向**，禁止 `children.position.z` 平移（南北航段会变成纵向排队）。

## 昼夜联动

- 全局 `env.t`（0 昼 → 1 夜）由太阳仰角驱动
- 所有发光体注册进灯组数组，每帧 `emissiveIntensity = t × 系数`
- 天穹色 lerp + 雾色联动 + 银河/流星（夜）+ 晨雾（晨）

## 皮的特性：可无限追加

皮只引用骨（航道/路网）和肉（建筑顶/沿岸）的位置数据，不反向影响——所以加船/加人不伤结构，放心迭代。加皮三步：建模函数 → 注册进 fleet/walkers 数组 → animate 加 update 分支。

## 验收（多帧）

- 连拍 3 帧 md5 对比：不同 = 在动；相同 = animate 冻结（后台标签页），需先唤醒再验
- 夜景单拍：灯组全亮确认
