# 画质工艺与自动验收（吸收自姊妹技能 threejs-scene-craft）

> 本文件是 city-3d-scene 与 `~/.workbuddy/skills/threejs-scene-craft/` 的整合笔记。
> 单场景工艺细节的完整配方读那边；本文件收录城市级项目最常用的部分。

## 一、画质地基（缺一项就露怯）

1. 渲染器：`outputColorSpace = SRGBColorSpace` + `ACESFilmicToneMapping`（曝光 1.0~1.2）+ `PCFSoftShadowMap`
2. 纹理：程序化 Canvas 纹理（256×256 够用），每类材质一个生成函数：
   - 木纹 = 底色 + 200 条贝塞尔半透明描边；灰泥 = 底色 + 18000 个 1px 噪点
   - 石材 = 底色 + 12000 随机斑块；草地 = 底色 + 10000 条短笔触
   - `colorSpace = SRGBColorSpace` + `RepeatWrapping`，anisotropy ≤ 4
3. 天空：ShaderMaterial 渐变球（BackSide），顶冷底暖；远景低多边形剪影 + 雾
4. 灯光三层：半球光定基调 → 平行光产主阴影 → **点光个位数**做氛围（每个都要有实体灯具载体）
5. 配色纪律：全场景材质集中一个常量对象，**禁止散落即兴色值**；低饱和暖调是高级感捷径；非金属 roughness ≥ 0.8

## 二、性能预算

- 重复物体一律 InstancedMesh；目标单视角 drawCalls < 150
- **shadowMap.autoUpdate = false**——静态场景不逐帧重算；太阳步进/门开合等动态事件时手动 `needsUpdate = true`（城市级项目此招直接消灭逐帧阴影重算）
- `setPixelRatio(Math.min(devicePixelRatio, 1.5))`
- 细节按距离分层：近处密（踢脚线/门把手等便宜细节极提完成度）、远处省

## 三、自动验收闭环（本方法论"验证阶梯"的落地工具）

用 Playwright 真实按键验收（模板：`~/.workbuddy/skills/threejs-scene-craft/scripts/verify_scene.cjs`，复制到项目改交互点位）：

- **真实键盘穿行**（keyboard.down('KeyW') 等待位置断言），禁止 teleport 代替
- 碰撞数值断言（撞墙后坐标范围）、每个交互点实际触发
- drawCalls 预算断言（< 150）
- 窄屏 390×844 无横向溢出（scrollWidth === innerWidth）
- 控制台 0 错误 + 概览/特色/夜景/移动端四张截图直出，**亲眼看过再交付**
- 无头浏览器软件渲染帧率低是正常的，等待超时 ≥ 45s，别把慢误判为卡死

场景需暴露 `window.__scene` 调试 API（state/position/aim/move/view/setTheme）作为验收探针——对应本技能的 window.__dbg / __snap。

## 四、单文件发布

- 离线单文件用 pack_single_file.cjs 内联 JS
- ⚠️ `String.replace(marker, 大段JS)` 会把压缩库里的 `$&`/`$'` 当特殊替换符 → 必须用**函数替换** `replace(marker, () => inline)`
- 打包后必须重跑完整验收（DOM 结构会变）
