// Playwright 真实按键验收模板（Three.js 场景专用）
// 用法：复制到项目目录，修改 TARGET 与交互点位，用受管 Node 运行：
//   "C:/Users/Administrator/.workbuddy/binaries/node/versions/22.22.2-6/node.exe" verify_scene.cjs
// 前提：场景暴露 window.__scene 调试 API（state/position/aim/move/view/setTheme/resume）。
// 注意：无头浏览器用软件渲染，帧率低属正常，等待超时不要低于 45s。

const {chromium}=require('C:/Users/Administrator/.workbuddy/binaries/node/workspace/node_modules/playwright');
const fs=require('fs');
const OUT='./outputs/';
const TARGET='file:///绝对路径/ scene.html'; // 或 http://127.0.0.1:端口

(async()=>{
const b=await chromium.launch({channel:'chrome',headless:true,args:['--enable-webgl','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const p=await b.newPage({viewport:{width:1000,height:700}});
const errors=[],checks=[];
p.on('pageerror',e=>errors.push(e.message));
p.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
const ok=(n,v)=>{checks.push({name:n,passed:!!v});if(!v)throw Error(n);};

await p.goto(TARGET,{waitUntil:'networkidle'});
await p.waitForFunction(()=>window.__scene?.state().frames>4);
await p.screenshot({path:OUT+'overview.png'});

// —— 进入漫游（按实际入口修改选择器）——
await p.click('#enter');
await p.waitForFunction(()=>__scene.state().mode==='walk');
ok('进入漫游',true);

// —— 真实按键穿行（禁止用 teleport 代替）——
await p.keyboard.down('KeyW');
await p.waitForFunction(()=>__scene.state().position[2]>3,{},{timeout:45000});
await p.keyboard.up('KeyW');
ok('真实W键穿过门洞',true);
await p.keyboard.down('KeyS');
await p.waitForFunction(()=>__scene.state().position[2]<-1,{},{timeout:45000});
await p.keyboard.up('KeyS');
ok('真实S键返回',true);

// —— 暂停 / 恢复 ——
await p.keyboard.press('Escape');
await p.waitForFunction(()=>__scene.state().mode==='paused');
ok('Esc暂停',true);
await p.click('#resume');
await p.waitForFunction(()=>__scene.state().mode==='walk');
ok('恢复',true);

// —— 碰撞数值断言（范围按场景实测值调整）——
const c=await p.evaluate(()=>{__scene.position(0,10);__scene.move(0,30);const back=__scene.state().position[2];__scene.position(0,-2.4);__scene.move(8,0);return{back,x:__scene.state().position[0]}});
ok('后墙阻挡',c.back<18.7&&c.back>18);
ok('侧墙阻挡',c.x<4.7&&c.x>4);

// —— 交互点逐个实测（站位 + 视线目标 + 按 E）——
async function interact(name,pos,target,keyword,flag){
  await p.evaluate(({pos,target})=>{__scene.position(...pos);__scene.aim(...target);},{pos,target});
  await p.waitForFunction(k=>(__scene.state().near||'').includes(k),keyword,{timeout:45000});
  await p.keyboard.press('KeyE');
  await p.waitForFunction(f=>__scene.state().discovered.includes(f),flag);
  ok(name,true);
}
// 示例：await interact('阅读信件',[2.7,-5.6,0],[2.63,.91,-6.28],'桌上的信','note');

// —— 性能预算断言 ——
const perf=await p.evaluate(()=>__scene.state());
ok('drawCalls预算',perf.drawCalls<150);

// —— 取景截图（按场景调整机位）——
await p.evaluate(()=>{document.body.classList.add('photo');__scene.view(6.1,2.3,16.8,-.4,1,4);});
await p.screenshot({path:OUT+'feature.png'});
await p.evaluate(()=>__scene.setTheme('night'));
await p.screenshot({path:OUT+'night.png'});

// —— 移动端 ——
await p.setViewportSize({width:390,height:844});
await p.evaluate(()=>{document.body.classList.remove('photo');__scene.resume();});
await p.screenshot({path:OUT+'mobile.png'});
ok('移动尺寸无横向溢出',await p.evaluate(()=>document.documentElement.scrollWidth===innerWidth));

ok('浏览器无运行错误',errors.length===0);
const state=await p.evaluate(()=>__scene.state());
fs.writeFileSync(OUT+'verification.json',JSON.stringify({checks,errors,state,collision:c},null,2));
console.log(JSON.stringify({checks,errors,state,collision:c},null,2));
await b.close();
})().catch(e=>{console.error(e);process.exit(1)});
